import os
import csv
import requests
import matplotlib.pyplot as plt
from datetime import datetime

print("⚡ INICIANDO EL SUPER BOT COMERCIAL...")

try:
    # PASO 1: Traer el precio en vivo
    url = "https://api.coinbase.com/v2/prices/BTC-USD/spot"
    datos = requests.get(url).json()
    precio_bitcoin = datos["data"]["amount"]
    
    ahora = datetime.now()
    fecha_hora_texto = ahora.strftime("%Y-%m-%d %H:%M:%S")
    hora_corta = ahora.strftime("%H:%M:%S")
    print(f"✅ Datos obtenidos: ${precio_bitcoin} USD a las {hora_corta}")

    # PASO 2: Guardar en el historial CSV
    archivo_existe = os.path.exists("historial_precios.csv")
    with open("historial_precios.csv", "a", encoding="utf-8") as archivo_csv:
        if not archivo_existe:
            archivo_csv.write("Fecha y Hora,Precio BTC (USD)\n")
        archivo_csv.write(f"{fecha_hora_texto},{precio_bitcoin}\n")

    # PASO 3: Leer el historial completo y recrear el gráfico
    horas = []
    precios = []
    with open("historial_precios.csv", "r", encoding="utf-8") as archivo:
        lector = csv.reader(archivo)
        next(lector) # Saltar títulos
        for fila in lector:
            horas.append(fila[0].split(" ")[1]) # Solo la hora
            precios.append(float(fila[1]))

    # Generar la imagen del gráfico
    plt.figure(figsize=(8, 4))
    plt.plot(horas, precios, marker="o", color="#00ffcc", linewidth=2)
    plt.title("TENDENCIA DE MERCADO EN VIVO", fontsize=12, fontweight="bold")
    plt.grid(True, linestyle="--", alpha=0.3)
    plt.savefig("grafico_actual.png")
    plt.close() # Cerramos el gráfico para liberar memoria
    print("📊 Gráfico de tendencias actualizado con éxito.")

    # PASO 4: Construir la página web e INYECTARLE la imagen del gráfico
    diseño_final = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Reporte Financiero Pro</title>
        <style>
            body {{ background-color: #0d0e15; color: #ffffff; font-family: sans-serif; text-align: center; padding: 20px; }}
            .tarjeta {{ background: #161824; border: 1px solid #00ffcc; padding: 30px; border-radius: 12px; display: inline-block; max-width: 500px; }}
            h1 {{ color: #00ffcc; margin-bottom: 5px; }}
            .precio {{ font-size: 32px; color: #fffb00; font-weight: bold; }}
            img {{ border: 2px solid #00ffcc; border-radius: 8px; margin-top: 20px; max-width: 100%; }}
        </style>
    </head>
    <body>
        <div class="tarjeta">
            <h1>📊 REPORTE EJECUTIVO</h1>
            <p>Generado automáticamente por el sistema</p>
            <hr style="border-color: #00ffcc;">
            <p><strong>ÚLTIMO PRECIO MONITOREADO:</strong></p>
            <p class="precio">${precio_bitcoin} USD</p>
            <p style="color: #888;">Actualizado el: {fecha_hora_texto}</p>
            <img src="grafico_actual.png" alt="Gráfico de tendencias">
        </div>
    </body>
    </html>
    """

    with open("reporte_final.html", "w", encoding="utf-8") as web:
        web.write(diseño_final)
        
    print("🚀 ¡PROYECTO COMPLETO! Abre 'reporte_final.html' en tu navegador.")

except Exception as e:
    print(f"❌ Algo falló en la automatización: {e}")